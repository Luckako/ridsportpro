import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { useAuthContext } from "@/components/auth-provider";
import { signOut } from "firebase/auth";
import { auth } from "@/lib/firebase";
import { useToast } from "@/hooks/use-toast";

export function Header() {
  const { user, userProfile } = useAuthContext();
  const { toast } = useToast();

  const handleSignOut = async () => {
    try {
      await signOut(auth);
      toast({
        title: "Utloggad",
        description: "Du har loggats ut framgångsrikt",
      });
    } catch (error) {
      toast({
        title: "Fel",
        description: "Kunde inte logga ut",
        variant: "destructive",
      });
    }
  };

  return (
    <header className="bg-white shadow-sm border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <Link href="/">
                <h1 className="text-xl font-bold text-gray-900">
                  RidSport<span className="text-primary">Pro</span>
                </h1>
              </Link>
            </div>
          </div>
          <nav className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-4">
              {user ? (
                <div className="flex items-center space-x-4">
                  <span className="text-sm text-gray-700">
                    Hej, {userProfile?.name || user.email}
                    {userProfile?.role && (
                      <span className="ml-1 text-xs text-gray-500">
                        ({userProfile.role})
                      </span>
                    )}
                  </span>
                  <Button variant="outline" onClick={handleSignOut}>
                    Logga ut
                  </Button>
                </div>
              ) : (
                <>
                  <Link href="/login">
                    <Button variant="ghost" className="text-gray-500 hover:text-gray-900">
                      Logga in
                    </Button>
                  </Link>
                  <Link href="/register">
                    <Button className="bg-primary hover:bg-primary/90">
                      Registrera
                    </Button>
                  </Link>
                </>
              )}
            </div>
          </nav>
        </div>
      </div>
    </header>
  );
}
